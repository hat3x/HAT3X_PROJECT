import { createClient } from "@supabase/supabase-js";

// Conexión manual al proyecto Supabase existente.
// La anon key es pública por diseño (RLS protege los datos).
const SUPABASE_URL = "https://tqgtbyhznzcadjoknvkf.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxZ3RieWh6bnpjYWRqb2tudmtmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4MDE1OTksImV4cCI6MjA5MTM3NzU5OX0.h9xb1AkAmQWvnxYYrMUJ3m7-GxdpMkQx0FDKXvlnPBQ";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storage: localStorage,
  },
});

export type AppRole = "cocina" | "caja" | "admin";
export type EstadoPedido =
  | "pendiente"
  | "recibido"
  | "preparando"
  | "listo"
  | "entregado"
  | "cancelado";
export type TipoPedido = "cocina" | "bebidas" | "mixto";
export type DestinoItem = "cocina" | "bebidas";
